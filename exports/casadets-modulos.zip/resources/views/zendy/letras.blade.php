@extends('layouts.app')

@section('content')
<div class="card">
    <div class="card-body">
        <h3 class="mb-1">Pago de letras (ZENDY)</h3>
        <p class="text-muted mb-0">Módulo en construcción.</p>
    </div>
</div>
@endsection
